"""
The entry point of the Python Wheel
"""

import sys

def main():
  # This method will print the provided arguments
  print('Hello from my func old school')
  print('Got arguments:')
  print(sys.argv)

if __name__ == '__main__':
  main()